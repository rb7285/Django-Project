from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('submit-request/', views.submit_request, name='submit_request'),
    path('request/<int:pk>/', views.request_detail, name='request_detail'),
    path('success/', views.success_page, name='success_page'),
    path('', views.home, name='home'),
    path('login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('service/', views.request_list, name='request_list'),

]
