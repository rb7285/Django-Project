from django.contrib import admin
from .models import Customer, ServiceRequest, RequestStatusHistory, CustomerSupportRepresentative # type: ignore

admin.site.register(Customer)
admin.site.register(ServiceRequest)
admin.site.register(RequestStatusHistory)
admin.site.register(CustomerSupportRepresentative)
