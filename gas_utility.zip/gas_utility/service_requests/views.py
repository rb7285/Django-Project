from django.shortcuts import render, redirect, HttpResponse
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from .models import Customer, ServiceRequest
from .forms import ServiceRequestForm, CustomerForm

@login_required
def submit_request(request):
    try:
        customer = request.user.customer
    except Customer.DoesNotExist:
        return HttpResponse("submit_request")

    if request.method == 'POST':
        form = ServiceRequestForm(request.POST, request.FILES)
        if form.is_valid():
            service_request = form.save(commit=False)
            service_request.customer = customer
            service_request.save()
            return redirect('success_page')
    else:
        form = ServiceRequestForm()

    return render(request, 'service_requests/submit_request.html', {'form': form})

@login_required
def request_list(request):
    if request.user.is_staff:
        service_requests = ServiceRequest.objects.all().order_by('-created_at')
    else:
        try:
            customer = request.user.customer
            service_requests = ServiceRequest.objects.filter(customer=customer).order_by('-created_at')
        except Customer.DoesNotExist:
            service_requests = ServiceRequest.objects.none()

    return render(request, 'service_requests/request_list.html', {'service_requests': service_requests})

from django.utils import timezone

@login_required
def request_detail(request, pk):
    service_request = ServiceRequest.objects.get(pk=pk)
    
    if request.method == 'POST':
        status = request.POST.get('status')
        if status == 'Resolved':
            service_request.status = 'Resolved'
            service_request.resolved_at = timezone.now()
        else:
            service_request.status = status
        
        service_request.save()
        return redirect('request_list')

    return render(request, 'service_requests/request_detail.html', {'service_request': service_request})

@login_required
def home(request):
    return render(request, 'service_requests/home.html')

def success_page(request):
    return render(request, 'service_requests/success.html')
